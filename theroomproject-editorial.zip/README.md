# The Room Project — Editorial Interactive

Approved static client-review edition. Private PHP admin and SMTP require the separate cPanel package. WhatsApp, Instagram and email links work directly. The preview form never sends or saves personal information.
