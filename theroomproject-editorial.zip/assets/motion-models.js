import * as T from './vendor/three.module.js';
import {eyePaths} from './eye-paths.js';

// A single, deliberately small family of brand-coloured studio miniatures.
// Every part is modelled in place; no remote models, textures or random objects.
export function createModelKit(colors) {
 const materials=[],geometries=[];
 const mat=color=>{const m=new T.MeshPhysicalMaterial({color,roughness:.32,metalness:.03,clearcoat:.42,clearcoatRoughness:.32});materials.push(m);return m;};
 const p={forest:mat(colors.green),pink:mat(colors.pink),lime:mat(colors.lime),highlight:mat('#ffffff')};
 function mesh(parent,geometry,material,x=0,y=0,z=0){geometries.push(geometry);const m=new T.Mesh(geometry,material);m.position.set(x,y,z);parent.add(m);return m;}
 function sphere(g,m,x,y,z,rx,ry=rx,rz=rx){const o=mesh(g,new T.SphereGeometry(1,32,24),m,x,y,z);o.scale.set(rx,ry,rz);return o;}
 function tube(g,m,points,r=.035){return mesh(g,new T.TubeGeometry(new T.CatmullRomCurve3(points.map(v=>new T.Vector3(...v))),40,r,12,false),m);}
 function roundShape(w,h,r){const s=new T.Shape(),x=-w/2,y=-h/2;r=Math.min(r,w/2,h/2);s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);s.closePath();return s;}
 function extrude(g,shape,m,depth=.15,bevel=.025,x=0,y=0,z=0){const geo=new T.ExtrudeGeometry(shape,{depth,steps:1,bevelEnabled:true,bevelSize:bevel,bevelThickness:bevel,bevelSegments:5,curveSegments:24});geo.translate(0,0,-depth/2);return mesh(g,geo,m,x,y,z);}
 function block(g,m,w,h,d,r,x=0,y=0,z=0){return extrude(g,roundShape(w,h,r),m,d,Math.min(.025,d*.2,r*.32),x,y,z);}
 function cylinder(g,m,r,h,x=0,y=0,z=0){return mesh(g,new T.CylinderGeometry(r,r,h,40),m,x,y,z);}
 function torus(g,m,r,t,x=0,y=0,z=0,arc=Math.PI*2){return mesh(g,new T.TorusGeometry(r,t,14,64,arc),m,x,y,z);}
 function sparkle(g,m=p.pink,size=.4,x=0,y=0,z=0){const s=new T.Shape();s.moveTo(0,size);s.bezierCurveTo(size*.18,size*.25,size*.25,size*.18,size,0);s.bezierCurveTo(size*.25,-size*.18,size*.18,-size*.25,0,-size);s.bezierCurveTo(-size*.18,-size*.25,-size*.25,-size*.18,-size,0);s.bezierCurveTo(-size*.25,size*.18,-size*.18,size*.25,0,size);s.closePath();return extrude(g,s,m,.12,.028,x,y,z);}
 function heart(g,m=p.pink,x=0,y=0,z=0){const s=new T.Shape();s.moveTo(0,-.36);s.bezierCurveTo(-.12,-.22,-.43,-.02,-.43,.20);s.bezierCurveTo(-.43,.49,-.10,.50,0,.29);s.bezierCurveTo(.10,.50,.43,.49,.43,.20);s.bezierCurveTo(.43,-.02,.12,-.22,0,-.36);return extrude(g,s,m,.14,.035,x,y,z);}
 function check(g,m=p.forest,z=.15){tube(g,m,[[-.18,0,z],[-.045,-.13,z],[.22,.17,z]],.04);}
 function eyePath(commands){const s=new T.Shape();for(const [kind,...v]of commands){if(kind==='M')s.moveTo((v[0]-421.3894)/700,-(v[1]-235.72)/700);else s.bezierCurveTo((v[0]-421.3894)/700,-(v[1]-235.72)/700,(v[2]-421.3894)/700,-(v[3]-235.72)/700,(v[4]-421.3894)/700,-(v[5]-235.72)/700);}s.closePath();return s;}
 function eyes(g,color){
  const pupils=[];
  for(const data of eyePaths){
   extrude(g,eyePath(data.body),p[color]||p.lime,.10,.012);
   const pupil=new T.Group();g.add(pupil);extrude(pupil,eyePath(data.pupil),p.forest,.016,.004,0,0,.065);
   extrude(pupil,eyePath(data.highlight),p.highlight,.012,.003,0,0,.079);pupils.push(pupil);
  }
  g.userData.pupils=pupils;
 }
 function arch(g,m,w,h,d,x=0,y=0,z=0){const r=w/2,s=new T.Shape();s.moveTo(-r,-h/2);s.lineTo(r,-h/2);s.lineTo(r,h/2-r);s.absarc(0,h/2-r,r,0,Math.PI,false);s.lineTo(-r,-h/2);s.closePath();return extrude(g,s,m,d,.025,x,y,z);}
 function camera(g){
  block(g,p.forest,1.02,.82,.26,.22);block(g,p.pink,.88,.68,.04,.16,0,0,.155);
  const lens=torus(g,p.forest,.23,.055,0,0,.22);sphere(g,p.lime,0,0,.205,.16,.16,.055);
  sphere(g,p.forest,.28,.22,.205,.043);block(g,p.lime,.23,.065,.11,.025,.28,.46,-.025);
 }
 function phone(g){
  block(g,p.forest,.68,1.06,.15,.12);block(g,p.lime,.56,.88,.035,.07,0,.015,.10);
  block(g,p.forest,.20,.035,.012,.015,0,.40,.13);block(g,p.pink,.16,.025,.014,.01,0,-.39,.132);
  torus(g,p.forest,.205,.026,0,.015,.15);tube(g,p.forest,[[-.14,-.11,.15],[-.20,-.21,.15],[-.06,-.17,.15]],.025);
  tube(g,p.forest,[[-.07,.10,.17],[-.09,.045,.17],[-.025,-.035,.17],[.045,-.08,.17],[.105,-.05,.17]],.036);
 }
 function roller(g){
  cylinder(g,p.pink,.17,.78,0,.25,0).rotation.z=Math.PI/2;
  for(const side of[-1,1]){const end=cylinder(g,p.forest,.14,.045,side*.415,.25,0);end.rotation.z=Math.PI/2;}
  tube(g,p.forest,[[.44,.25,0],[.50,.25,0],[.50,-.02,0],[.08,-.02,0],[.08,-.24,0]],.036);
  block(g,p.lime,.16,.40,.17,.065,.08,-.43,0);block(g,p.forest,.075,.17,.018,.03,.08,-.43,.098);
  block(g,p.lime,.49,.07,.025,.03,-.06,.28,.17);
 }
 function room(g){
  arch(g,p.forest,1.04,1.14,.10,0,.07,-.22);arch(g,p.pink,.87,1.00,.025,0,.04,-.15);
  block(g,p.forest,1.1,.14,.78,.04,0,-.46,.14);block(g,p.lime,.97,.18,.69,.08,0,-.29,.15);
  block(g,p.pink,.44,.13,.46,.06,.20,-.16,.23);block(g,p.lime,.40,.23,.18,.07,-.24,-.11,-.03);
  for(const x of[-.43,.43])block(g,p.forest,.075,.16,.08,.02,x,-.57,.40);
  const mobile=new T.Group();g.add(mobile);tube(mobile,p.forest,[[.27,.55,-.10],[.27,.36,-.10]],.012);sphere(mobile,p.lime,.27,.28,-.10,.085);
 }
 function gift(g){
  block(g,p.lime,.83,.69,.64,.08,0,-.12,0);block(g,p.forest,.90,.18,.70,.05,0,.25,0);
  block(g,p.pink,.13,.89,.018,.025,0,-.04,.347);block(g,p.pink,.90,.13,.025,.02,0,.25,.373);
  block(g,p.pink,.14,.018,.70,.02,0,.36,0);
  for(const side of[-1,1]){const loop=torus(g,p.pink,.16,.038,side*.16,.48,.0);loop.scale.set(1.2,.73,1);loop.rotation.z=side*.5;}
  sphere(g,p.lime,0,.40,.04,.075);
 }
 function nursery(g){
  block(g,p.forest,.94,.12,.63,.035,0,-.38,0);block(g,p.pink,.83,.11,.54,.06,0,-.27,0);
  for(const x of[-.47,.47])for(const z of[-.3,.3])block(g,p.forest,.055,.75,.055,.02,x,-.11,z);
  for(const z of[-.30,.30]){block(g,p.lime,1,.065,.06,.025,0,.15,z);for(let x=-.34;x<=.35;x+=.17)block(g,p.lime,.034,.46,.034,.016,x,-.085,z);}
  for(const x of[-.47,.47])block(g,p.lime,.055,.065,.64,.02,x,.15,0);
  tube(g,p.forest,[[.46,.20,-.30],[.46,.67,-.30],[.20,.75,-.25],[-.06,.65,-.20]],.028);
  tube(g,p.forest,[[-.06,.65,-.20],[-.06,.48,-.20]],.008);sphere(g,p.pink,-.06,.40,-.20,.085);
 }
 function orbit(g){sparkle(g,p.pink,.37,0,0,.08);const ring=torus(g,p.lime,.52,.045);ring.rotation.x=1.05;ring.rotation.y=.35;sphere(g,p.forest,.46,.16,.19,.08);}
 function palette(g){
  const shape=new T.Shape();shape.moveTo(.40,.18);shape.bezierCurveTo(.4,.48,-.25,.58,-.48,.15);shape.bezierCurveTo(-.7,-.3,-.05,-.56,.19,-.31);shape.bezierCurveTo(.45,-.05,.08,-.02,.40,.18);shape.closePath();
  extrude(g,shape,p.lime,.13,.03);for(const[x,y,m]of[[-.28,.10,p.pink],[-.08,.31,p.forest],[.15,.26,p.pink],[-.20,-.16,p.forest]])sphere(g,m,x,y,.11,.075,.075,.025);
  const brush=new T.Group();g.add(brush);block(brush,p.forest,.065,.74,.065,.025,.29,-.02,.16);block(brush,p.pink,.12,.20,.08,.025,.29,.37,.16);brush.rotation.z=-.45;
 }
 function chat(g){
  block(g,p.forest,.83,.54,.13,.17,.13,-.13,-.03);block(g,p.pink,.83,.54,.16,.17,-.10,.14,.11);
  const tip=new T.Shape();tip.moveTo(-.39,.0);tip.lineTo(-.39,-.21);tip.lineTo(-.17,.0);tip.closePath();extrude(g,tip,p.pink,.16,.01,0,0,.11);
  for(const x of[-.30,-.10,.10])sphere(g,p.forest,x,.15,.21,.035);
 }
 function cards(g){for(const[x,angle,color]of[[-.20,.25,p.forest],[.04,0,p.pink],[.24,-.20,p.lime]]){const card=new T.Group();g.add(card);card.position.set(x,0,x+.18);card.rotation.z=angle;block(card,color,.52,.76,.08,.07);if(color===p.lime)check(card,p.forest,.07);}}
 function house(g){
  const s=new T.Shape();s.moveTo(-.44,-.40);s.lineTo(.44,-.40);s.lineTo(.44,.10);s.lineTo(0,.50);s.lineTo(-.44,.10);s.closePath();extrude(g,s,p.lime,.20,.035);arch(g,p.forest,.26,.46,.035,0,-.18,.14);const h=new T.Group();g.add(h);heart(h,p.pink,0,.21,.17);h.scale.setScalar(.30);
 }
 function search(g){torus(g,p.forest,.32,.09,-.10,.12,.03);sphere(g,p.pink,-.10,.12,.03,.25,.25,.05);torus(g,p.lime,.31,.036,-.10,.12,.13);const handle=block(g,p.lime,.15,.49,.17,.06,.26,-.32,0);handle.rotation.z=.68;tube(g,p.forest,[[.12,-.12,0],[.21,-.24,0]],.055);}
 const builders={roller,room,gift,nursery,orbit,palette,chat,cards,camera,phone,search,heart:g=>heart(g,p.lime),house,spark:g=>sparkle(g)};
 return {
  create(name,color='lime'){
   const sculpt=new T.Group();if(name==='eyes')eyes(sculpt,color);else(builders[name]||builders.spark)(sculpt);
   const box=new T.Box3().setFromObject(sculpt),size=box.getSize(new T.Vector3()),center=box.getCenter(new T.Vector3());
   sculpt.position.sub(center);const unit=new T.Group();unit.add(sculpt);unit.scale.setScalar((name==='eyes'?2.92:1.40)/Math.max(size.x,size.y,size.z));
   const model=new T.Group();model.add(unit);model.userData={name,pupils:sculpt.userData.pupils||[],baseX:name==='eyes'?0:.10,baseY:name==='eyes'?0:-.24};return model;
  },
  dispose(){for(const g of geometries)g.dispose();for(const m of materials)m.dispose();}
 };
}

export function addStudioLights(scene){
 scene.add(new T.HemisphereLight('#ffffff','#244d43',2.3));
 const key=new T.DirectionalLight('#ffffff',3.2);key.position.set(-3,5,6);scene.add(key);
 const rim=new T.DirectionalLight('#ffc6ff',1.0);rim.position.set(4,1,-1);scene.add(rim);
}
