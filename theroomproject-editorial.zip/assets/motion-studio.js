import * as T from './vendor/three.module.js';
import {createModelKit,addStudioLights} from './motion-models.js';

const settings=window.ROOM_MOTION||{},reduced=matchMedia('(prefers-reduced-motion: reduce)');
const root=document.documentElement;
root.dataset.motion='ready';
if(settings.cardDepth!==false)root.classList.add('depth-enabled');
function eyeControls(enabled){for(const el of document.querySelectorAll('.eyes-play')){el.disabled=!enabled;el.setAttribute('aria-label',enabled?'Make the brand eyes wink':'The Room Project eyes');}}
eyeControls(settings.interactiveEyes!==false&&!reduced.matches);
reduced.addEventListener('change',()=>eyeControls(settings.interactiveEyes!==false&&!reduced.matches&&root.dataset.sculpture!=='fallback'));

// Reveal only below the fold. Initial content never waits for JavaScript or WebGL.
const revealTargets=[...document.querySelectorAll('.section-heading,.package-heading,.package-summary,.social-heading,.social-card,.step-heading,.step-body,.values-grid article,.detail-story,.inclusion-list li,.faq-section>div')];
if(settings.scrollReveals!==false&&!reduced.matches&&'IntersectionObserver'in window){
 const revealObserver=new IntersectionObserver(entries=>{for(const e of entries)if(e.isIntersecting){e.target.classList.add('is-revealed');revealObserver.unobserve(e.target);}},{threshold:.08,rootMargin:'0px 0px -22px'});
 for(const el of revealTargets){if(el.getBoundingClientRect().top>innerHeight+40){el.classList.add('reveal-pending');revealObserver.observe(el);}}
 reduced.addEventListener('change',e=>{if(e.matches){document.querySelectorAll('.reveal-pending').forEach(el=>el.classList.add('is-revealed'));revealObserver.disconnect();}});
}

// A restrained physical response, with no motion during touch scrolling.
if(settings.pointerTilt!==false&&!reduced.matches&&matchMedia('(hover:hover) and (pointer:fine)').matches){
 for(const el of document.querySelectorAll('.hero-visual,.social-card,.about-image')){
  let frame=0,tx=0,ty=0;
  const update=()=>{frame=0;el.style.setProperty('--tilt-x',tx+'deg');el.style.setProperty('--tilt-y',ty+'deg');};
  el.addEventListener('pointermove',event=>{const r=el.getBoundingClientRect();tx=-(event.clientY-r.top-r.height/2)/r.height*2;ty=(event.clientX-r.left-r.width/2)/r.width*2;if(!frame)frame=requestAnimationFrame(update);},{passive:true});
  el.addEventListener('pointerleave',()=>{tx=ty=0;cancelAnimationFrame(frame);update();},{passive:true});
 }
}

const progress=document.querySelector('.reading-progress');
if(progress){let ticking=false;const update=()=>{ticking=false;const available=document.documentElement.scrollHeight-innerHeight;progress.style.transform=`scaleX(${available>0?scrollY/available:0})`;};addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(update);}},{passive:true});update();}

// One GPU context is shared by every slot; output is copied to a small local
// canvas so native clipping, links, scrolling and dialog stacking remain intact.
function startStudio(){
 const slots=[...document.querySelectorAll('[data-sculpt]')];if(!slots.length)return;
 let renderer;
 try{renderer=new T.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});}catch{root.dataset.sculpture='fallback';eyeControls(false);return;}
 renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.NeutralToneMapping;
 renderer.setPixelRatio(1);renderer.setClearColor(0,0);
 const kit=createModelKit(settings.colors||{green:'#004c43',pink:'#ffc6ff',lime:'#c0df88'});
 const scene=new T.Scene(),camera=new T.OrthographicCamera(-1,1,1,-1,.1,30);camera.position.z=6;addStudioLights(scene);
 const models=new Map(),entries=[];let raf=0,last=0,dirty=true,disposed=false,lost=false,canvasW=0,canvasH=0;
 for(const el of slots){
  if(el.dataset.sculpt!=='eyes'&&settings.sculptedIcons===false)continue;
  const name=el.dataset.sculpt,color=el.dataset.eyeColor||'lime',key=name+':'+color;
  if(!models.has(key)){const model=kit.create(name,color);model.visible=false;scene.add(model);models.set(key,model);}
  const canvas=document.createElement('canvas');canvas.className='sculpt-canvas';canvas.setAttribute('aria-hidden','true');const ctx=canvas.getContext('2d');if(!ctx)continue;el.append(canvas);
  const e={el,name,key,canvas,ctx,visible:false,hover:0,target:0,gazeX:0,gazeY:0,x:0,y:0,blink:0,lastPaint:0,w:0,h:0};entries.push(e);
  const parent=el.closest('a,button,.room-package,.process-step,.values-grid article')||el;
  const enter=()=>{if(reduced.matches)return;e.target=1;dirty=true;request();};
  const leave=()=>{e.target=0;dirty=true;request();};
  parent.addEventListener('pointerenter',enter,{passive:true});parent.addEventListener('pointerleave',leave,{passive:true});parent.addEventListener('focusin',enter);parent.addEventListener('focusout',leave);
  if(name==='eyes')el.addEventListener('click',()=>{if(settings.interactiveEyes!==false&&!reduced.matches){e.blink=performance.now();dirty=true;request();}});
 }
 const eyeEntries=entries.filter(e=>e.name==='eyes');
 function request(){if(!raf&&!disposed&&!lost&&!document.hidden)raf=requestAnimationFrame(paint);}
 function paint(stamp){
  raf=0;if(disposed||lost||document.hidden)return;
  const dt=Math.min(last?(stamp-last)/1000:1/60,.04);last=stamp;let moving=false;
  for(const e of entries){
   if(!e.visible||e.el.closest('[hidden],[inert]'))continue;
   const h=reduced.matches?0:e.target,old=e.hover;e.hover+=(h-e.hover)*(1-Math.exp(-22*dt));
   const interactive=settings.interactiveEyes!==false&&!reduced.matches;
   const gx=interactive?e.gazeX:0,gy=interactive?e.gazeY:0;
   e.x+=(gx-e.x)*(1-Math.exp(-20*dt));e.y+=(gy-e.y)*(1-Math.exp(-20*dt));
   const blinking=interactive&&e.blink&&stamp-e.blink<240;
   const active=Math.abs(h-e.hover)>.001||Math.abs(e.x-gx)>.001||Math.abs(e.y-gy)>.001||blinking||e.wasBlinking;
   e.wasBlinking=blinking;
   moving||=active;
   if(!dirty&&!active&&Math.abs(e.hover-old)<.001&&e.lastPaint)continue;
   const r=e.el.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,1.8);
   const w=Math.max(32,Math.min(900,Math.ceil(r.width*dpr))),height=Math.max(32,Math.min(600,Math.ceil(r.height*dpr)));
   if(!r.width||!r.height)continue;
   if(w!==e.w||height!==e.h){e.canvas.width=w;e.canvas.height=height;e.w=w;e.h=height;}
   if(w!==canvasW||height!==canvasH){renderer.setSize(w,height,false);canvasW=w;canvasH=height;}
   const ratio=w/height;camera.left=-ratio;camera.right=ratio;camera.top=1;camera.bottom=-1;camera.updateProjectionMatrix();
   const model=models.get(e.key),hover=e.hover;
   model.rotation.set(model.userData.baseX+hover*.05,model.userData.baseY+hover*.23,hover*(e.name==='roller'?-.12:.055));
   model.scale.setScalar(1+hover*.065);model.position.y=hover*.035;
   if(e.name==='eyes'){
    model.rotation.x=-e.y*.035;model.rotation.y=e.x*.06;
    model.scale.y=blinking?1-Math.sin((stamp-e.blink)/240*Math.PI)*.62:1;
    for(const pupil of model.userData.pupils)pupil.position.set(e.x*.025,e.y*.018,0);
   }
   model.visible=true;renderer.render(scene,camera);e.ctx.clearRect(0,0,w,height);e.ctx.drawImage(renderer.domElement,0,0,w,height);model.visible=false;
   e.el.classList.add('sculpt-ready');e.el.dataset.sculptState='ready';e.el.dataset.response=hover.toFixed(3);e.lastPaint=stamp;
  }
  dirty=false;root.dataset.sculpture='ready';if(moving)request();
 }
 let pointerFrame=0,pointerX=0,pointerY=0;
 const look=()=>{pointerFrame=0;if(settings.interactiveEyes===false||reduced.matches)return;for(const e of eyeEntries){if(!e.visible)continue;const r=e.el.getBoundingClientRect();e.gazeX=T.MathUtils.clamp((pointerX-r.left-r.width/2)/Math.max(200,r.width),-1,1);e.gazeY=T.MathUtils.clamp(-(pointerY-r.top-r.height/2)/Math.max(180,r.height),-1,1);}request();};
 addEventListener('pointermove',event=>{if(event.pointerType==='touch')return;pointerX=event.clientX;pointerY=event.clientY;if(!pointerFrame)pointerFrame=requestAnimationFrame(look);},{passive:true});
 document.addEventListener('pointerleave',()=>{eyeEntries.forEach(e=>e.gazeX=e.gazeY=0);request();});
 const observer=new IntersectionObserver(items=>{for(const item of items){const e=entries.find(e=>e.el===item.target);if(e)e.visible=item.isIntersecting;}dirty=true;request();},{rootMargin:'60px'});
 const resize=new ResizeObserver(()=>{dirty=true;request();});entries.forEach(e=>{observer.observe(e.el);resize.observe(e.el);});
 const mutation=new MutationObserver(()=>{dirty=true;request();});mutation.observe(document.body,{subtree:true,attributes:true,attributeFilter:['hidden','inert']});
 reduced.addEventListener('change',()=>{dirty=true;entries.forEach(e=>{e.target=0;e.gazeX=e.gazeY=0;});request();});
 document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(raf);raf=0;}else{last=0;dirty=true;request();}});
 renderer.domElement.addEventListener('webglcontextlost',event=>{event.preventDefault();lost=true;cancelAnimationFrame(raf);raf=0;entries.forEach(e=>e.el.classList.remove('sculpt-ready'));root.dataset.sculpture='fallback';eyeControls(false);});
 renderer.domElement.addEventListener('webglcontextrestored',()=>{lost=false;dirty=true;eyeControls(settings.interactiveEyes!==false&&!reduced.matches);request();});
 addEventListener('pagehide',event=>{cancelAnimationFrame(raf);cancelAnimationFrame(pointerFrame);raf=0;if(event.persisted)return;disposed=true;observer.disconnect();resize.disconnect();mutation.disconnect();kit.dispose();renderer.dispose();});
 addEventListener('pageshow',event=>{if(event.persisted){last=0;dirty=true;request();}});request();
}
startStudio();
